import java.util.Scanner;

public class PastryShop_03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String cake = scanner.nextLine();
        int numOfOrderCake = Integer.parseInt(scanner.nextLine());
        int day = Integer.parseInt(scanner.nextLine());

        switch (cake){
            case "Cake":
                if (day <= 15) {
                    double cakes = 24 * numOfOrderCake;
                    if (cakes >= 100 && cakes <= 200) {
                        cakes = cakes - cakes * 0.15;
                    } else if (cakes > 200) {
                        cakes = cakes - cakes * 0.25;
                    }

                    cakes = cakes - cakes * 0.10;
                    System.out.printf("%.2f",cakes);
                }else if(day<=22){
                    double cakes = 28.70 * numOfOrderCake;
                    if (cakes >= 100 && cakes <= 200) {
                        cakes = cakes - cakes * 0.15;
                    } else if (cakes > 200) {
                        cakes = cakes - cakes * 0.25;
                    }
                    System.out.printf("%.2f",cakes);
                }else {
                    double cakes = 28.70 * numOfOrderCake;
                    System.out.printf("%.2f",cakes);
                }
                break;
            case "Souffle":
                if (day <= 15) {
                    double souffle = 6.66 * numOfOrderCake;

                    if (souffle >= 100 && souffle <= 200) {
                        souffle = souffle - souffle * 0.15;
                    } else if (souffle > 200) {
                        souffle = souffle - souffle * 0.25;
                    }

                    souffle = souffle - souffle * 0.10;

                    System.out.printf("%.2f",souffle);
                }else if(day<=22){
                    double souffle = 9.80 * numOfOrderCake;
                    if (souffle >= 100 && souffle <= 200) {
                        souffle = souffle - souffle * 0.15;
                    } else if (souffle > 200) {
                        souffle = souffle - souffle * 0.25;
                    }
                    System.out.printf("%.2f",souffle);
                }else {
                    double souffle = 9.80 * numOfOrderCake;
                    System.out.printf("%.2f",souffle);
                }
                break;
            case "Baklava":
                if (day <= 15) {
                    double baklava = 12.60 * numOfOrderCake;
                    if (baklava >= 100 && baklava <= 200) {
                        baklava = baklava - baklava * 0.15;
                    } else if (baklava > 200) {
                        baklava = baklava - baklava * 0.25;
                    }

                    baklava = baklava - baklava * 0.10;

                    System.out.printf("%.2f",baklava);
                }else if(day<=22) {
                    double baklava = 16.98 * numOfOrderCake;
                    if (baklava >= 100 && baklava <= 200) {
                        baklava = baklava - baklava * 0.15;
                    } else if (baklava > 200) {
                        baklava = baklava - baklava * 0.25;
                    }
                    System.out.printf("%.2f",baklava);
                }else {
                    double baklava = 16.98 * numOfOrderCake;
                    System.out.printf("%.2f",baklava);
                }
                break;

        }

    }
}