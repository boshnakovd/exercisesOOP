import java.util.Scanner;

public class ChristmasGifts_05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int age = Integer.parseInt(scanner.nextLine());
        int kids = 0;
        int adults = 0;
        int moneyForToys = 0;
        int moneyForSweaters = 0;
        String command = scanner.nextLine();
        while (!command.equals("Christmas")){
            while (age <= 16){
                kids++;

                if (age > 16){
                    adults++;

                }
                age = Integer.parseInt(scanner.nextLine());
            }


        }

    }
}