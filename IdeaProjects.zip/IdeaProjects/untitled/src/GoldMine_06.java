import java.util.Scanner;

public class GoldMine_06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int numberLocation = Integer.parseInt(scanner.nextLine());
        int totalGold = 0;
        double currentAverage = 0;

        for (int i = 1; i <= numberLocation ; i++) {
            double average = Double.parseDouble(scanner.nextLine());
            currentAverage = average;

            int days  = Integer.parseInt(scanner.nextLine());
            for (int j = 1; j <= days ; j++) {
                int gold = Integer.parseInt(scanner.nextLine());
                totalGold = totalGold + gold;
                currentAverage = totalGold * 1.0 / days;
                if (j == days) {
                    if (currentAverage >= average) {
                        System.out.printf("Good job! Average gold per day: %.2f.%n", currentAverage);
                    } else {
                        System.out.printf("You need %.2f gold.%n", Math.abs(average - currentAverage));
                    }
                    totalGold = 0;
                }
            }

        }

    }
}