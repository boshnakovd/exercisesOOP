import java.util.Scanner;

public class CatFood_04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int countCats = Integer.parseInt(scanner.nextLine());
        int group1 = 0;
        int group2 = 0;
        int group3 = 0;
        double sumAllGrams = 0;
        for (int currentCat = 1; currentCat <= countCats ; currentCat++) {
            double foodPerCat = Double.parseDouble(scanner.nextLine());
            if (foodPerCat < 200){
                group1++;
                sumAllGrams += foodPerCat;
            } else if (foodPerCat < 300){
                group2++;
                sumAllGrams += foodPerCat;
            } else if (foodPerCat < 400){
                group3++;
                sumAllGrams += foodPerCat;
            }
        }
        double kgFood = sumAllGrams / 1000;
        double priceFoodPerDay = kgFood * 12.45;
        System.out.printf("Group 1: %d cats.%nGroup 2: %d cats.%nGroup 3: %d cats.%nPrice for food per day: %.2f lv.", group1, group2, group3, priceFoodPerDay);


    }
}