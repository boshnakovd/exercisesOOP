import java.util.Scanner;

public class MiningRig_01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int priceForVideoCard = Integer.parseInt(scanner.nextLine());
        int priceForConvertor = Integer.parseInt(scanner.nextLine());
        double priceElectricityPerDay = Double.parseDouble(scanner.nextLine());
        double earningFromOneRigPerDay = Double.parseDouble(scanner.nextLine());
        int countVideoCard = 13;
        int countConvertor = 13;
        double priceAllVideoCards = priceForVideoCard * countVideoCard;
        double priceAllConvertors = priceForConvertor * countConvertor;
        double spendmoney = priceAllConvertors + priceAllVideoCards + 1000;
        earningFromOneRigPerDay = earningFromOneRigPerDay - priceElectricityPerDay;
        double sumAllEarnPerDay = countVideoCard * earningFromOneRigPerDay;
        System.out.printf("%.0f%n", spendmoney);
        System.out.printf("%.0f", Math.ceil(spendmoney / sumAllEarnPerDay));



    }
}
