import java.util.Scanner;

public class BeerAndChips_02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String nameFootballFan = scanner.nextLine();
        double expectedBudget = Double.parseDouble(scanner.nextLine());
        int countBottles = Integer.parseInt(scanner.nextLine());
        int packsChips = Integer.parseInt(scanner.nextLine());
        double priceOneBeer = 1.20;
        double sumAllBeer = countBottles * priceOneBeer;
        double priceOneChips = sumAllBeer - (sumAllBeer * 0.55);
        double sumAllChips = Math.ceil(priceOneChips * packsChips);
        double allSum = sumAllBeer + sumAllChips;
        double diff = Math.abs(allSum-expectedBudget);
        if (allSum <= expectedBudget){
            System.out.printf("%s bought a snack and has %.2f leva left.", nameFootballFan, diff);
        } else {
            System.out.printf("%s needs %.2f more leva!", nameFootballFan, diff);
        }

    }
}
