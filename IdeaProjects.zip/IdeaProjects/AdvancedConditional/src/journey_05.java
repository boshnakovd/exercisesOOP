import java.io.PrintStream;
import java.util.Scanner;

public class journey_05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double budget = Double.parseDouble(scanner.nextLine());
        String season = scanner.nextLine();
        String trip = "";
        String destination = "";
        if (budget <= 100) {
            destination = "Bulgaria";
            if (season.equals("summer")) {
                trip = "Camp";
                budget = budget - (budget * 0.70);
            } else if (season.equals("winter")) {
                trip = "Hotel";
                budget = budget - (budget * 0.30);
            }
        }
        else if (budget <= 1000){
            destination = "Balkans";
            if (season.equals("summer")){
                trip = "Camp";
                budget = budget - (budget * 0.60);
            } else if (season. equals("winter")){
                trip = "Hotel";
                budget = budget - (budget * 0.20);
            }
        }
        else if (budget > 1000){
            destination = "Europe";
            budget = budget - (budget * 0.10);
            if (season. equals("summer")){
                trip = "Hotel";
            } else if (season.equals("winter")){
                trip = "Hotel";
            }
        }
        System.out.printf("Somewhere in %s\n%s - %.2f", destination, trip, budget);

    }
}

