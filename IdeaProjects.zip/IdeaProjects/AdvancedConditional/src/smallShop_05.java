import java.util.Scanner;

public class smallShop_05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String product = scanner.nextLine();
        String town = scanner.nextLine();
        double quantity = Double.parseDouble(scanner.nextLine());
        switch (town){
            case "Sofia":
                if (product.equals("coffee")){
                    System.out.printf("%.1f", quantity * 0.50);
                } else if (product.equals("water")){
                    System.out.printf("%.1f", quantity * 0.80);
                } else if (product.equals("beer")){
                    System.out.printf("%.1f", quantity * 1.20);
                } else if (product.equals("sweets")){
                    System.out.printf("%.1f", quantity * 1.45);
                } else if (product.equals("peanuts")){
                    System.out.printf("%.1f", quantity * 1.60);
                }
                break;
            case "Plovdiv":
                if(product.equals("coffee")){
                    System.out.printf("%.1f", quantity * 0.40);
                } else if (product.equals("water")){
                    System.out.printf("%.1f", quantity * 0.70);
                } else if (product.equals("beer")){
                    System.out.printf("%.1f", quantity * 1.15);
                } else if (product.equals("sweets")){
                    System.out.printf("%.1f", quantity * 1.30);
                } else if (product.equals("peanuts")){
                    System.out.printf("%.1f", quantity * 1.50);
                }
                break;
            case "Varna":
                if(product.equals("coffee")){
                    System.out.printf("%.1f", quantity * 0.45);
                } else if (product.equals("water")){
                    System.out.printf("%.1f", quantity * 0.70);
                } else if (product.equals("beer")){
                    System.out.printf("%.1f", quantity * 1.10);
                } else if (product.equals("sweets")){
                    System.out.printf("%.1f", quantity * 1.35);
                } else if (product.equals("peanuts")){
                    System.out.printf("%.1f", quantity * 1.55);
                }
                break;
        }

    }
}
