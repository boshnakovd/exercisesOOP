import java.util.Scanner;

public class hotelroomvtori_07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String month = scanner.nextLine();
        int nights = Integer.parseInt(scanner.nextLine());
        String type = "";
        double priceStdio = 0;
        double priceApartment = 0;


        switch (month) {
            case "May":
            case "October":
                priceStdio = 50.0;
                priceApartment = 65.0;
                if (nights <= 7) {
                    priceStdio = priceStdio * nights;
                } else if (nights <= 14) {
                    priceStdio = priceStdio * 0.95 * nights;
                    priceApartment = priceApartment * nights;
                } else if (nights > 14) {
                    priceStdio = priceStdio * 0.70 * nights;
                    priceApartment = priceApartment * 0.90 * nights;
                }

                break;
            case "June":
            case "September":
                priceStdio = 75.20;
                priceApartment = 68.70;
                if (nights <= 14) {
                    priceStdio = priceStdio * nights;
                    priceApartment = priceApartment * nights;
                } else if (nights > 14) {
                    priceStdio = priceStdio * 0.80 * nights;
                    priceApartment = priceApartment * 0.90 * nights;
                }
                break;
            case "July":
            case "August":
                priceStdio = 76.0;
                priceApartment = 77.0;
                priceApartment = priceApartment * 0.90 * nights;
                priceStdio = priceStdio * nights;
                break;
        }
        System.out.printf("Apartment: %.2f lv.\nStudio: %.2f lv.", priceApartment, priceStdio);
    }
}
