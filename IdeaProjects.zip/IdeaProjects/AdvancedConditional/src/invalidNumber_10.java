import java.util.Scanner;

public class invalidNumber_10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int number = Integer.parseInt(scanner.nextLine());
        //валидно -> [100;200] или е 0
        //невалидно -> в противен случай
        if ((number >= 100 && number <= 200) || number == 0) {
            System.out.println();
        } else {
            System.out.println("invalid");
        }
    }
}