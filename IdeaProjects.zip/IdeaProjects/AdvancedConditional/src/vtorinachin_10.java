import java.util.Scanner;

public class vtorinachin_10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int number = Integer.parseInt(scanner.nextLine());
        //валидно -> [100;200] или е 0
        //невалидно -> в противен случай
        boolean isValid = (number >= 100 && number <= 200) || number == 0;
        //isValid = true -> валидно
        //isValid = false -> невалидно

        //ако числото е неавлидно -> invalid
        if (!isValid) {
            System.out.println("invalid");
        }
    }
}