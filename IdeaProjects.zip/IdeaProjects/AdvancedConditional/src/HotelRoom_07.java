import java.util.Scanner;

public class HotelRoom_07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);
        String month = scanner.nextLine();
        int nights = Integer.parseInt (scanner.nextLine());
        double studio = 0.00;
        double apartment = 0.00;
        switch (month){
            case "May":
            case "October":
                studio = 50.00;
                apartment = 65.00; break;
            case "June":
            case "September":
                studio = 75.20;
                apartment = 68.70; break;
            case "July":
            case "August":
                studio = 76.00;
                apartment = 77.00; break;
        }
        if (nights > 14){
            apartment = apartment * 0.9;
            if (month.equals ("June") || month.equals("September")){
                studio = studio * 0.8;
            } else if (month.equals("May") || month.equals("October")){
                studio = studio * 0.7;
            }
        } else if (nights > 7 && (month.equals("May") || month.equals("October"))){
            studio = studio * 0.95;
        }
        System.out.printf("Apartment: %.2f lv.%n", (apartment*nights));
        System.out.printf("Studio: %.2f lv.", (studio*nights));
    }
}