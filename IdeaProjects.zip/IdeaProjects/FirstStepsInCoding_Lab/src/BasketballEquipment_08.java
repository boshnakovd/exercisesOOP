import java.util.Scanner;

public class BasketballEquipment_08 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int yearTaxBasket = Integer.parseInt(scanner.nextLine());
        double priceShoes = yearTaxBasket * 0.60;
        double priceEquipment = priceShoes - (priceShoes * 0.20);
        double basketBall = priceEquipment / 4;
        double Accessories = basketBall / 5;
        double totalSum = yearTaxBasket + priceShoes + priceEquipment + basketBall + Accessories;
        System.out.println(totalSum);
    }
}
