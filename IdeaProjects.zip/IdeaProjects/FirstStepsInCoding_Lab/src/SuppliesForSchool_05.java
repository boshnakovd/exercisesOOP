import java.util.Scanner;

public class SuppliesForSchool_05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int pens = Integer.parseInt(scanner.nextLine());
        int markers = Integer.parseInt(scanner.nextLine());
        int litresPrep = Integer.parseInt(scanner.nextLine());
        int percent = Integer.parseInt(scanner.nextLine());
        double sumPens = pens * 5.80;
        double sumMarkers = markers * 7.20;
        double sumPrep = litresPrep * 1.20;
        double allSupliesSum = sumPens + sumMarkers + sumPrep;
        double sumWithDiscount = allSupliesSum - (allSupliesSum * (percent / 100.0));
        System.out.println(sumWithDiscount);

    }
}
