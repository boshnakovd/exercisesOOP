import java.util.Scanner;

public class JudgePractice_03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double degreesCelsium = Double.parseDouble(scanner.nextLine());
        double degreesFarenheit = degreesCelsium * 9 / 5 + 32;
        System.out.printf("%.2f", degreesFarenheit);
    }
}
