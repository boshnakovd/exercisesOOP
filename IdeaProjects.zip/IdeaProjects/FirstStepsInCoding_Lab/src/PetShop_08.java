import java.util.Scanner;

public class PetShop_08 {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double dogfood = Double.parseDouble(scan.nextLine());
        double dogfoodprice = dogfood * 2.50;
        double catfood = Double.parseDouble(scan.nextLine());
        double catfoodprice = catfood * 4.00;
        System.out.println(dogfoodprice + catfoodprice);

    }
}
