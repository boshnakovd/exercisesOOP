import java.util.Scanner;

public class Repaint_06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nylon = Integer.parseInt(scanner.nextLine());
        int paint = Integer.parseInt(scanner.nextLine());
        int razr = Integer.parseInt(scanner.nextLine());
        int hrs = Integer.parseInt(scanner.nextLine());
        double sumNylon = (nylon + 2) * 1.50;
        double sumPaint = (paint * 1.10) * 14.50;
        double sumRazr = razr * 5.00;
        double sumAll = sumNylon + sumPaint + sumRazr + 0.40;
        double sumWorkers = (sumAll * 0.30) * hrs;
        double result = sumAll + sumWorkers;
        System.out.println(result);

    }
}