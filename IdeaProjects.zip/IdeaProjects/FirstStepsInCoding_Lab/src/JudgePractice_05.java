import java.util.Scanner;

public class JudgePractice_05 {

        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);

            double w = Double.parseDouble(scanner.nextLine()) * 100;
            double h = Double.parseDouble(scanner.nextLine()) * 100 - 100;
            double rows = Math.floor(w / 120);
            double columns = Math.floor(h / 70);
            double countWorkPlaces = rows * columns - 1 -2;

            System.out.printf("%.0f", countWorkPlaces);
        }
    }

