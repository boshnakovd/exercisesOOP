import java.util.Scanner;

public class JudgePractice_04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double vegPerKG = Double.parseDouble(scanner.nextLine());
        double frPerKG = Double.parseDouble(scanner.nextLine());
        double kgVeg = Double.parseDouble(scanner.nextLine());
        double kgFr = Double.parseDouble(scanner.nextLine());
        double priceVeg = vegPerKG * kgVeg;
        double priceFr = frPerKG * kgFr;
        double priceAll = (priceFr + priceVeg) / 1.94;
        System.out.printf("%.2f", priceAll);

    }
}
