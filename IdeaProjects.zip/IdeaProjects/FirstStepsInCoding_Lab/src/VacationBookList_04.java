import java.util.Scanner;

public class VacationBookList_04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int countPages = Integer.parseInt(scanner.nextLine());
        int readPagesPerHr = Integer.parseInt(scanner.nextLine());
        int days = Integer.parseInt(scanner.nextLine());
        int TotalHours = countPages / readPagesPerHr;
        int HoursPerDay = TotalHours / days;
        System.out.println(HoursPerDay);

    }
}
