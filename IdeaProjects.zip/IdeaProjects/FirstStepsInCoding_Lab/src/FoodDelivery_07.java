import java.util.Scanner;

public class FoodDelivery_07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int countChickens = Integer.parseInt(scanner.nextLine());
        int countFish = Integer.parseInt(scanner.nextLine());
        int countVeg = Integer.parseInt(scanner.nextLine());
        double priceChicken = countChickens * 10.35;
        double priceFish = countFish * 12.40;
        double priceVeg = countVeg * 8.15;
        double priceAll = priceChicken + priceFish + priceVeg;
        double priceDesert = (priceAll * 0.20) ;
        double result = priceAll + priceDesert + 2.50;
        System.out.println(result);
    }
}
