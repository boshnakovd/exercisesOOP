public class HelloSoftUni_01 {
    public static void main(String[] args) {
        System.out.println("Hello SoftUni");
    }
    }

