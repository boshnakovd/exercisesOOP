
public class num1to100_01 {
    public static void main(String[] args) {
        for (int number = 1; number <= 100; ++number){
            System.out.println(number);
        }
    }
}
