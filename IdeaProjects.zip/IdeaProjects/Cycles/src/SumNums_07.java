import java.util.Scanner;

public class SumNums_07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int n = Integer.parseInt(scanner.nextLine());
        int sum = 0;
        for (int num = 1; num <= n; num++){
            int value = Integer.parseInt(scanner.nextLine());
            sum += value;

        }
        System.out.println(sum);
    }


}
