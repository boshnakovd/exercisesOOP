import java.util.Scanner;

public class P03SumNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int sum = 0;
        int n = Integer.parseInt(scanner.nextLine());
        while (sum < n){
            int current = Integer.parseInt(scanner.nextLine());
            sum += current;
        }
        System.out.println(sum);
    }
}
