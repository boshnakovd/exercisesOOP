import java.util.Scanner;

public class P07MinNum {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int min = Integer.MAX_VALUE;
        String input = scanner.nextLine();

        while (!input.equals("Stop")){
            int i = Integer.parseInt(input);
            if (i < min){
                min = i;
            }
            input = scanner.nextLine();
        }
        System.out.println(min);

    }
}
