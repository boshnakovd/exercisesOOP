import java.util.Scanner;

public class P01ChristmasPrep {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int countPaper = Integer.parseInt(scanner.nextLine());;
        int countPlat = Integer.parseInt(scanner.nextLine());;
        double litresGlue = Double.parseDouble(scanner.nextLine());
        int discount = Integer.parseInt(scanner.nextLine()) ;

        double pricePaper = countPaper  * 5.80;
        double pricePlat = countPlat  * 7.20;
        double priceGlue = litresGlue * 1.20;

        double totalPrice = pricePaper + pricePlat + priceGlue;


        double sumWithDiscount = totalPrice * (100 - discount) / 100;

        System.out.printf("%.3f", sumWithDiscount );
    }
}