public class P06Substitute {
}
