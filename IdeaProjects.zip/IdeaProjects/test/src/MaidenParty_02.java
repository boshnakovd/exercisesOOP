import java.util.Scanner;

public class MaidenParty_02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //1.	Цена на моминското парти - реално число в интервала [1.00 … 10000.00]
        //2.	Брой любовни послания - цяло число в интервала [0… 1000]
        //3.	Брой восъчни рози - цяло число в интервала [0 … 1000]
        //4.	Брой ключодържатели - цяло число в интервала [0 … 1000]
        //5.	Брой карикатури - цяло число в интервала [0 … 1000]
        //6.	Брой късмети изненада - цяло число в интервала [0 … 1000]
        double priceParty = Double.parseDouble(scanner.nextLine());
        int loveLetters = Integer.parseInt(scanner.nextLine());
        int roses = Integer.parseInt(scanner.nextLine());
        int keyDrops = Integer.parseInt(scanner.nextLine());
        int caricatures = Integer.parseInt(scanner.nextLine());
        int surprises = Integer.parseInt(scanner.nextLine());
        //Цени на различните артикули:
        //•	Любовно послание - 0.60 лв.
        //•	Восъчна роза - 7.20 лв.
        //•	Ключодържател - 3.60 лв.
        //•	Карикатура - 18.20 лв.
        //•	Късмет изненада - 22 лв.
        double priceLoveLetters = loveLetters * 0.60;
        double priceRoses = roses * 7.20;
        double priceKeyDrops = keyDrops * 3.60;
        double priceCar = caricatures * 18.20;
        double priceSurprise = surprises * 22;
        double sumAllObj = priceCar + priceKeyDrops + priceSurprise + priceRoses + priceLoveLetters;
        int countAllObj = loveLetters + roses + keyDrops + caricatures + surprises;

        if (countAllObj > 25) {
            double discount = sumAllObj - (sumAllObj * 0.35);
            discount = sumAllObj - discount;
            double endSum = sumAllObj - discount;
            double hosting = endSum * 0.10;
            double earning = endSum - hosting;
            if (earning > priceParty) {
                double leftSum = earning - priceParty;
                System.out.printf("Yes! %.2f lv left.", leftSum);
            } else {
                double needSum = priceParty - earning;
                System.out.printf("Not enough money! %.2f lv needed.", needSum);
            }

        } else if (countAllObj < 25){
            double hosting = sumAllObj * 0.10;
            double earning = sumAllObj - hosting;
            if (earning > priceParty) {
                double leftSum = earning - priceParty;
                System.out.printf("Yes! %.2f lv left.", leftSum);
            } else {
                double needSum = priceParty - earning;
                System.out.printf("Not enough money! %.2f lv needed.", needSum);
            }
        }


    }
}


