import java.util.Scanner;

public class Exam_04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //•	На първия ред – броя на студентите явили се на изпит – цяло число в интервала [1...1000]
        //•	За всеки един студент на отделен ред – оценката от изпита – реално число в интервала [2.00...6.00]
        int countStudents = Integer.parseInt(scanner.nextLine());
        //Ред 1 -	"Top students: {процент студенти с успех 5.00 или повече}%"
        //Ред 2 -	"Between 4.00 and 4.99: {между 4.00 и 4.99 включително}%"
        //Ред 3 -	"Between 3.00 and 3.99: {между 3.00 и 3.99 включително}%"
        //Ред 4 -	"Fail: {по-малко от 3.00}%"
        //Ред 5 -	"Average: {среден успех}"
            double group1 = 0;
            double group2 = 0;
            double group3 = 0;
            double group4 = 0;
            double Avg = 0;
        for (int currentStudent = 1; currentStudent <= countStudents ; currentStudent++) {
            double gradePerStudent = Double.parseDouble(scanner.nextLine());
            if (gradePerStudent < 3.00){
                group4++;
                Avg += gradePerStudent;
            } else if (gradePerStudent <= 3.99 ){
                group3++;
                Avg += gradePerStudent;
            } else if (gradePerStudent <= 4.99){
                group2++;
                Avg += gradePerStudent;
            } else if (gradePerStudent >= 5){
                group1++;
                Avg += gradePerStudent;
            }
        }
        double percentExcellent = group1 / countStudents * 100;
        double percentGood = group2 / countStudents * 100;
        double percentDecent = group3 / countStudents * 100;
        double percentFails = group4 / countStudents * 100;
        double AverageMark = Avg / countStudents;
        System.out.printf("Top students: %.2f%%%nBetween 4.00 and 4.99: %.2f%%%nBetween 3.00 and 3.99: %.2f%%%nFail: %.2f%%%nAverage: %.2f", percentExcellent, percentGood, percentDecent, percentFails, AverageMark);
    }
}
