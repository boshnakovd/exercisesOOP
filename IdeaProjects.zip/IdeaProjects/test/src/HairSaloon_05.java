import java.util.Scanner;

public class HairSaloon_05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int targetForTheDay = Integer.parseInt(scanner.nextLine());
        int priceMans = 15;
        int priceLadies = 20;
        int priceKids = 10;
        int priceTouchUp = 20;
        int priceFullColor = 30;
        int earning = 0;
        String command = scanner.nextLine();
        while (!command.equals("closed")){
            if (command.equals("haircut")){
                switch (command){
                    case "ladies":
                        earning += priceLadies;
                    case "kids":
                        earning += priceKids;
                    case "mens":
                        earning += priceMans;
                }
            } else if (command.equals("color")){
                if(command.equals("touch up")) {
                    earning += priceTouchUp;
                } else if (command.equals("full color")){
                    earning += priceFullColor;
                }
            }
        }
        if (earning >= targetForTheDay){
            System.out.printf("You have reached your target for the day!%n" +
                    "Earned money: %dlv.", earning);
        }
    }
}
