import java.util.Scanner;

public class SantaHoliday_03 {
    public static void main (String [] args) {
        Scanner scanner = new Scanner(System.in);
        int days = Integer.parseInt(scanner.nextLine());
        String room = scanner.nextLine();
        String grade = scanner.nextLine();
        int nights = days - 1;
        double price = 0;

        switch (room) {
            case "room for one person":
                price = 18;
                break;
            case "apartment":
                price = 25;
                if (days < 10) {
                    price = price - (price * 0.30);
                } else if (days <= 15) {
                    price = price - (price * 0.35);
                } else if (days > 15) {
                    price = price * 0.50;
                }
                break;
            case "president apartment":
                price = 35;
                if (days < 10) {
                    price = price - (price * 0.10);
                } else if (days <= 15) {
                    price = price - (price * 0.15);
                } else if (days > 15) {
                    price = price - (price * 0.20);
                }
                break;
        }
        double sumAll = price * nights;
        if (grade.equals("positive")){
            double bonus = sumAll + (sumAll * 0.25);
            System.out.printf("%.2f", bonus);
        } else if (grade.equals("negative")){
            double discount = sumAll - (sumAll * 0.10);
            System.out.printf("%.2f", discount);
        }
    }
}