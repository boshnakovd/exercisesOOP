import java.util.Scanner;

public class P06Substitute {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int i = Integer.parseInt(scanner.nextLine());
        int j = Integer.parseInt(scanner.nextLine());
        int k = Integer.parseInt(scanner.nextLine());
        int l = Integer.parseInt(scanner.nextLine());
        int count = 0;
        for (int m = i; m <= 8; m++) {
            for (int n = 0; n >=j ; n--) {
                for (int o = k; o <= 8; o++) {
                    for (int p = 0; p >= l ; p--) {
                        boolean isPossible = (m % 2 == 0 && o % 2 == 0
                                            && n % 2 != 0 && p % 2 != 0);
                        boolean isValid = (m != o || n != p);
                        if (count == 6){
                            return;
                        }
                        if (isPossible && isValid){
                            System.out.printf("%d%d - %d%d", m, n, o, p);
                            count++;
                            continue;
                        }
                        if (isPossible){
                            System.out.printf("Cannot change the same player.");
                        }
                    }
                }
            }
        }
    }
}
