import java.util.Scanner;

public class P05Travelling {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //повтаряме: въвеждаме дестинация (държава или "End")
        //спираме: дестинация == "End"
        //продължаваме: дестинация != "End"
        String destination = scanner.nextLine();

        while (!destination.equals("End")) {
            //държава
            //1. определям колко струва екскурзията до държавата
            double needMoney = Double.parseDouble(scanner.nextLine());
            double savedMoney = 0;
            //2. повтарям: въвеждам суми + спестявам (savedMoney += суми)
            //спираме: savedMoney >= needMoney
            //продължаваме: savedMoney < needMoney
            while (savedMoney < needMoney) {
                double sum = Double.parseDouble(scanner.nextLine()); //сума, която спестявам
                savedMoney += sum;
            }
            //savedMoney >= needMoney -> отива на екскурзия
            System.out.printf("Going to %s!%n", destination);

            destination = scanner.nextLine();
        }
    }
}