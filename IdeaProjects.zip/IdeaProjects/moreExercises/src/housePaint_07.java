import java.util.Scanner;

public class housePaint_07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double x = Double.parseDouble(scanner.nextLine());
        double y = Double.parseDouble(scanner.nextLine());
        double h = Double.parseDouble(scanner.nextLine());
        double doorheight = 1.2;
        double window = 1.5;
        double side = x * y;
        double windows = window * window;
        double sum = 2 * side - 2 * windows;
        double back = x * x;
        double entry = doorheight * 2;
        double all = 2 * back - entry;
        double area1 = sum + all;
        double greenPaint = area1 / 3.4;
        double rectangles = 2 * side;
        double triangles = 2 * (x * (h / 2));
        double area2 = rectangles + triangles;
        double redPaint = area2 / 4.3;
        System.out.printf(("%.2f\n") + ("%.2f"), greenPaint, redPaint);
    }
}
