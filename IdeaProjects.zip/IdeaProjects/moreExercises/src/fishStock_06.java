import java.util.Scanner;

public class fishStock_06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double priceScPerKG = Double.parseDouble(scanner.nextLine());
        double priceCacaPerKG = Double.parseDouble(scanner.nextLine());
        double Palamud = Double.parseDouble(scanner.nextLine());
        double Safrid = Double.parseDouble(scanner.nextLine());
        double Midi = Double.parseDouble(scanner.nextLine());
        //•	Паламуд – 60% по-скъп от скумрията
        //•	Сафрид – 80% по-скъп от цацата
        //•	Миди – 7.50 лв. за килограм
        double  pricePalamudPerKG = priceScPerKG + (priceScPerKG * 0.60);
        double sumPalamud = Palamud * pricePalamudPerKG;
        double priceSafridPerKG = priceCacaPerKG + (priceCacaPerKG * 0.80);
        double sumSafrid = Safrid * priceSafridPerKG;
        double priceMidiPerKG = 7.50;
        double sumMidi = Midi * priceMidiPerKG;
        double sumAll = sumMidi + sumSafrid + sumPalamud;
        System.out.printf("%.2f", sumAll);

    }
}
