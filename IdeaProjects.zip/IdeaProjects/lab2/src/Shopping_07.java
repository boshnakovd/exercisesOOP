import java.util.Scanner;

public class Shopping_07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double budget = Double.parseDouble(scanner.nextLine());
        int N = Integer.parseInt(scanner.nextLine());
        int M = Integer.parseInt(scanner.nextLine());
        int P = Integer.parseInt(scanner.nextLine());
        double priceN = N * 250.0;
        double priceM= M * (priceN - (priceN * 0.65));
        double priceP = P * (priceN - (priceN * 0.90));
        double priceAll = priceN + priceM + priceP;
        if (N > M){
            priceAll = priceAll - (priceAll * 0.15);
        }
            double diff = Math.abs(priceAll - budget);
        if(budget >= priceAll){
            System.out.printf("You have %.2f leva left!", diff);
        } else {
            System.out.printf("Not enough money! You need %.2f leva more!", diff);
        }
    }
}
