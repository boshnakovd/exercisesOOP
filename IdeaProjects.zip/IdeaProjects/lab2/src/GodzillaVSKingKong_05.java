import java.util.Scanner;

public class GodzillaVSKingKong_05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double budget = Double.parseDouble(scanner.nextLine());
        int statists = Integer.parseInt(scanner.nextLine());
        double dress = Double.parseDouble(scanner.nextLine());
        double decor = budget * 0.10;
        double dressPrice = statists * dress;
        if (statists > 150){
             dressPrice = dressPrice - (dressPrice * 0.10);
        }
        double allSum = dressPrice + decor;
        double diff = Math.abs(budget - allSum);
        if(budget >= allSum){
            System.out.printf("Action!\n" +
                    "Wingard starts filming with %.2f leva left.", diff);
        } else {
            System.out.printf("Not enough money!\n" +
                    "Wingard needs %.2f leva more.", diff);
        }
    }
}
