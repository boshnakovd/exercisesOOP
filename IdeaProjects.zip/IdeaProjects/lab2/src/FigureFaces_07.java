import java.util.Scanner;

import static java.lang.System.out;

public class FigureFaces_07 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String figure = scanner.nextLine();

        if(figure.equals("square")){
            double lenght = Double.parseDouble(scanner.nextLine());
            double  result = lenght * lenght;
            System.out.printf("%.3f", result);
        } else if(figure.equals("rectangle")){
            double lenght1 = Double.parseDouble(scanner.nextLine());
            double lenght2 = Double.parseDouble(scanner.nextLine());
            double result = lenght1 * lenght2;
            System.out.printf("%.3f", result);
        } else if(figure.equals("circle")){
            double radius = Double.parseDouble(scanner.nextLine());
            double result = (radius * radius) * Math.PI;
            System.out.printf("%.3f", result);
        } else if (figure.equals("triangle")){
            double l = Double.parseDouble(scanner.nextLine());
            double h = Double.parseDouble(scanner.nextLine());
            double result = (l * h) / 2;
            System.out.printf("%.3f", result);
        }
    }
}
