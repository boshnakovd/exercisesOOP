import java.util.Scanner;

public class LunchBreak_08 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String serial = scanner.nextLine();
        int episodeEndurance = Integer.parseInt(scanner.nextLine());
        int brake = Integer.parseInt(scanner.nextLine());
        double lunch = brake / 8.0;
        double rest = brake / 4.0;
        double timeleft = brake - lunch - rest;
        double diff = Math.abs(timeleft - episodeEndurance);
        if(timeleft >= episodeEndurance){
            System.out.printf("You have enough time to watch %s and left with %.0f minutes free time.", serial, Math.ceil(diff));
        } else {
            System.out.printf("You don't have enough time to watch %s, you need %.0f more minutes.", serial, Math.ceil(diff));
        }
    }
}
