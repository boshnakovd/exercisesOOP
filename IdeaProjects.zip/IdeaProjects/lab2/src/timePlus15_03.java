import java.util.Scanner;

public class timePlus15_03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int h = Integer.parseInt(scanner.nextLine());
        int m = Integer.parseInt(scanner.nextLine());
        int allMin = (h * 60) + m + 15;
        int hour = allMin / 60;
        int min = allMin % 60;
        if(hour > 23){
        hour = 0;
        }

        System.out.printf("%d:%02d", hour, min);
    }
}
