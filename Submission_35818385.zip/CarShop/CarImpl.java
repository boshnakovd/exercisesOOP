package CarShop;

public class CarImpl implements Car{

    private String model;
    private String color;
    private Integer HorsePower;
    private String CountryProduced;
    public CarImpl(String model, String color, Integer horsePower, String countryProduced) {
        this.model = model;
        this.color = color;
        HorsePower = horsePower;
        CountryProduced = countryProduced;
    }
        @Override
        public String getModel() {
            return model;
        }

        @Override
        public String getColor() {
            return color;
        }

        @Override
        public Integer getHorsePower() {
            return HorsePower;
        }

        @Override
        public String getCountryProduced() {
            return CountryProduced;
        }
    public String toString() {
        return String.format("This is %s produced in %s and have %d tires", model, CountryProduced, Car.TIRES);
    }
}
