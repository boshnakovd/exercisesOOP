package singleInheritance;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        RandomArrayList<Integer> randomArrayList = new RandomArrayList();
        randomArrayList.add(47);
        randomArrayList.add(15);
        randomArrayList.add(99);
        randomArrayList.add(63);
        randomArrayList.add(52);
        System.out.println(randomArrayList.getRandomElement());
    }

}
